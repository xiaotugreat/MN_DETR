import warnings
warnings.filterwarnings('ignore')
from ultralytics import RTDETR
from ultralytics import YOLO


if __name__ == '__main__':
    model = RTDETR('ultralytics/cfg/models/rt-detr/rtdetr-r50.yaml')
    # model = YOLO('ultralytics/cfg/models/my_yolo/yolov8.yaml')
    model.train(data='cell_dataset/mydata/MY_DATA_data.yaml',
                cache=False,
                imgsz=640,
                # epochs=100,
                epochs=150,
                batch=8,
                workers=4, # Windows下出现莫名其妙卡主的情况可以尝试把workers设置为0
                project='runs/train/new-r50(bc=8)',
                name='exp',
                )